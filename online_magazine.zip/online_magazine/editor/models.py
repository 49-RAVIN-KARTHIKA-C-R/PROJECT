from django.db import models

# Create your models here.
class Editor(models.Model):
    ed_id = models.AutoField(primary_key=True)
    username = models.CharField(max_length=50)
    mobile = models.CharField(max_length=50)
    email = models.CharField(max_length=50)
    password = models.CharField(max_length=50)
    photo = models.CharField(max_length=50)

    class Meta:
        managed = False
        db_table = 'editor'
