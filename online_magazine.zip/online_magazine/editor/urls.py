from django.conf.urls import url
from editor import views
urlpatterns=[
    url('editors_reg',views.editors_reg),
    url('upd_pro_editor',views.update_profile_editor),
    url('view_editor',views.view_editor)
]