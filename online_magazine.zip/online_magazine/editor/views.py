from django.shortcuts import render
from editor.models import Editor

# Create your views here.


def editors_reg(request):
    if request.method=="POST":
        obj=Editor()
        obj.username=request.POST.get('uname')
        obj.email=request.POST.get('email')
        obj.mobile=request.POST.get('mob')
        obj.photo=request.POST.get('fileupload')
        obj.password=request.POST.get('passwd')
        obj.save()
    return render(request,"editor/EDITORS REGISTRATION.HTML")


def update_profile_editor(request):
    return render(request,"editor/UPDATE_PROFILE_EDITOR.HTML")


def view_editor(request):
    return render(request,"editor/view_editor.html")