from django.conf.urls import url
from students import views
urlpatterns=[
    url('stu_reg',views.st_reg),
    url('stu_view',views.st_view),
    url('upd_pro_stu',views.upd_profile_st)
]