from django.shortcuts import render
from students.models import Students
# Create your views here.

def st_reg(request):
    if request.method=='POST':
        obj=Students()
        obj.mobile=request.POST.get('mob')
        obj.password=request.POST.get('passwd')
        obj.photo=request.POST.get('fileupload')
        obj.email=request.POST.get('email')
        obj.username=request.POST.get('uname')
        obj.course=request.POST.get('course')
        obj.dept=request.POST.get('dept')
        obj.sem=request.POST.get('sem')
        obj.save()

    return render(request,"students/STUDENTS REGISTRATION FORM.HTML")


def st_view(request):
    return render(request,"students/students_view.html")


def upd_profile_st(request):
    return render(request,"students/UPDATE_PROFILE_STUDENT.HTML")
