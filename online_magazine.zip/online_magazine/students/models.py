from django.db import models

# Create your models here.
class Students(models.Model):
    st_id = models.AutoField(primary_key=True)
    username = models.CharField(max_length=50)
    mobile = models.CharField(max_length=50)
    email = models.CharField(max_length=50)
    dept = models.CharField(max_length=50)
    course = models.CharField(max_length=50)
    sem = models.CharField(max_length=50)
    password = models.CharField(max_length=50)
    photo = models.CharField(max_length=50)

    class Meta:
        managed = False
        db_table = 'students'
