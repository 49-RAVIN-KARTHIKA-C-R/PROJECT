from django.db import models

# Create your models here.
class Article(models.Model):
    a_id = models.AutoField(primary_key=True)
    u_id = models.IntegerField()
    article_name = models.CharField(max_length=50)
    article_type = models.CharField(max_length=50)
    photo = models.CharField(max_length=50)
    articles = models.CharField(max_length=50)

    status = models.CharField(max_length=50)

    class Meta:
        managed = False
        db_table = 'article'
