from django.shortcuts import render
from article.models import Article

# Create your views here.
def article_sts(request):

    return render(request,"article/ariticle_status_view.html")



def article_upl_faculty(request):
    if request.method=='POST':
        obj=Article()
        obj.article_name=request.POST.get('aname')
        obj.photo=request.POST.get('fileupload')
        obj.article_type=request.POST.get('atype')
        obj.articles=request.POST.get('article')
        obj.status='pending'
        obj.save()
    return render(request,"article/ARTICLES UPLOADING FOR FALCUTIES.HTML")


def article_upl_students(request):
    if request.method=='POST':
        obj=Article()
        obj.article_name = request.POST.get('aname')
        obj.photo = request.POST.get('fileupload')
        obj.article_type = request.POST.get('atype')
        obj.articles = request.POST.get('article')
        obj.status="pending"
        obj.save()
    return  render(request, "article/ARTICLES UPLOADING FOR STUDENTS.HTML")


def magazine_view(request):
    obj=Article.objects.all()
    context={
        'objval':obj,
    }

    return render(request,"article/magazine_view.html",context)


def publish(request):
    return  render(request,"article/publish.html")


def view_article_st(request):
    return render(request,"article/view_articles_students.html")
