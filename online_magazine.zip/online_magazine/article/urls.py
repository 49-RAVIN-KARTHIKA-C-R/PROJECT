from django.conf.urls import url
from article import views
urlpatterns=[
    url('article_sts/',views.article_sts),
    url('article_up_facl',views.article_upl_faculty),
    url('article_up_stu',views.article_upl_students),
    url('magazine_views',views.magazine_view),
    url('publishs',views.publish),
    url('view_article_stu',views.view_article_st)
]