from django.shortcuts import render
from invite.models import Invite
import datetime
# Create your views here.

def invite_article(request):
    if request.method=='POST':
        obj=Invite()
        obj.submission_starts=request.POST.get('start')
        obj.submission_end=request.POST.get('end')
        obj.time=datetime.datetime.today()
        obj.save()


    return render(request,"invite/INVITE ARTICLE.HTML")


def view_invite_article(request):
    return render(request,"invite/view_invite_article.html")