from django.conf.urls import url
from invite import views
urlpatterns=[
    url('invite_articles',views.invite_article),
    url('view_invite',views.view_invite_article)
]