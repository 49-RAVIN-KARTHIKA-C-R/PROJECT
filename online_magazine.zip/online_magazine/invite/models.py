from django.db import models

# Create your models here.
class Invite(models.Model):
    in_id = models.AutoField(primary_key=True)
    submission_starts = models.DateField()
    submission_end = models.DateField()
    time = models.TimeField()

    class Meta:
        managed = False
        db_table = 'invite'

