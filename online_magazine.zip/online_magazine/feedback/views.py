from django.shortcuts import render
from feedback.models import Feedback
import datetime
# Create your views here.


def feedback(request):
    if request.method=="POST":
        obj=Feedback()
        obj.feedback=request.POST.get('feedback')
        obj.date=datetime.datetime.today()
        obj.reply='pending'
        obj.st_id=1
        obj.time=datetime.datetime.today()
        obj.save()
    return render(request,"feedback/FEEDBACK.HTML")


def view_feedback(request):
    obj=Feedback.objects.all()
    context={
        'objval':obj,
    }
    return render(request,"feedback/view_feed.html",context)