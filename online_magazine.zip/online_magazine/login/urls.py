from django.conf.urls import url
from login import views
urlpatterns=[
    url('logins',views.login_page)
]