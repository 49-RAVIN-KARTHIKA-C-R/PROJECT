from django.shortcuts import render
from comments.models import Comments
import datetime
# Create your views here.
def comment_box(request):
    if request.method=='POST':
        obj=Comments()
        obj.comments=request.POST.get('comment here')
        obj.st_id=1
        obj.date=datetime.datetime.today()
        obj.save()
    return render(request,"comments/COMMENT BOX.HTML")


def view_comment(request):
    return  render(request,"comments/view_comments.html")