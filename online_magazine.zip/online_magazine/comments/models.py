from django.db import models

# Create your models here.
class Comments(models.Model):
    c_id = models.AutoField(primary_key=True)
    comments = models.CharField(max_length=50)
    date = models.DateField()
    st_id = models.IntegerField()

    class Meta:
        managed = False
        db_table = 'comments'
