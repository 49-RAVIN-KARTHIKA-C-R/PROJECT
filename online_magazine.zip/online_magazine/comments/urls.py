from django.conf.urls import url
from comments import views
urlpatterns=[
    url('comment_box',views.comment_box),
    url('view_comments',views.view_comment)
]